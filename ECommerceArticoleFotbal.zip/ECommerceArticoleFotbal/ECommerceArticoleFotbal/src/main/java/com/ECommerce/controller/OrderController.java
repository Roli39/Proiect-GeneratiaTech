package com.ECommerce.controller;

import com.ECommerce.Order;
import com.ECommerce.OrderDetails;
import com.ECommerce.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/pay")
    public String paymentSuccess(@RequestParam String userName, @RequestParam double paidAmount) {
        return orderService.paymentSuccess(userName, paidAmount);
    }

    @GetMapping("/all")
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }

    @GetMapping("/{userId}")
    public List<Order> getOrdersByUser(@PathVariable String userId) {
        return orderService.getOrdersByUserId(userId);
    }

    @GetMapping("/{userId}/details")
    public List<OrderDetails> getAllOrderDetails(@PathVariable String userId) {
        return orderService.getAllOrderDetails(userId);
    }

    @PostMapping("/ship")
    public String shipOrder(@RequestParam String orderId, @RequestParam String prodId) {
        return orderService.shipNow(orderId, prodId);
    }
}
