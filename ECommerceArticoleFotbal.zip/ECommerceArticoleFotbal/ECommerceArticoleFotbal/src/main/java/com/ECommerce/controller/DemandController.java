package com.ECommerce.controller;

import com.ECommerce.Demand;
import com.ECommerce.service.DemandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/demand")
public class DemandController {

    @Autowired
    private DemandService demandService;

    @PostMapping("/add")
    public boolean addProductDemand(@RequestParam String userId, @RequestParam String prodId, @RequestParam int demandQty) {
        return demandService.addProduct(userId, prodId, demandQty);
    }

    @DeleteMapping("/remove")
    public boolean removeProductDemand(@RequestParam String userId, @RequestParam String prodId) {
        return demandService.removeProduct(userId, prodId);
    }

    @GetMapping("/list/{prodId}")
    public List<Demand> getDemandsForProduct(@PathVariable String prodId) {
        return demandService.haveDemanded(prodId);
    }
}
