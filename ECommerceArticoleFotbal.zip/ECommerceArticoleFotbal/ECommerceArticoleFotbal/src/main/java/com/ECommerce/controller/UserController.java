package com.ECommerce.controller;

import com.ECommerce.User;
import com.ECommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    /**
     * Register a new user.
     */
    @PostMapping("/register")
    public String registerUser(
            @RequestParam String userName,
            @RequestParam Long mobileNo,
            @RequestParam String emailId,
            @RequestParam String address,
            @RequestParam int pinCode,
            @RequestParam String password) {
        return userService.registerUser(userName, mobileNo, emailId, address, pinCode, password);
    }

    /**
     * Check if an email is already registered.
     */
    @GetMapping("/is-registered")
    public boolean isEmailRegistered(@RequestParam String emailId) {
        return userService.isRegistered(emailId);
    }

    /**
     * Validate user credentials.
     */
    @PostMapping("/login")
    public String validateCredentials(@RequestParam String emailId, @RequestParam String password) {
        return userService.isValidCredential(emailId, password);
    }

    /**
     * Get user details.
     */
    @GetMapping("/details")
    public User getUserDetails(@RequestParam String emailId, @RequestParam String password) {
        return userService.getUserDetails(emailId, password);
    }

    /**
     * Get the first name of a user by email.
     */
    @GetMapping("/first-name")
    public String getFirstName(@RequestParam String emailId) {
        return userService.getFName(emailId);
    }

    /**
     * Get the address of a user by email.
     */
    @GetMapping("/address")
    public String getUserAddress(@RequestParam String userId) {
        return userService.getUserAddr(userId);
    }
}
