package com.ECommerce.controller;

import com.ECommerce.Product;
import com.ECommerce.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    /**
     * Add a new product with an image.
     */
    @PostMapping("/add")
    public ResponseEntity<String> addProduct(
            @RequestParam String prodName,
            @RequestParam String prodType,
            @RequestParam String prodInfo,
            @RequestParam double prodPrice,
            @RequestParam int prodQuantity,
            @RequestParam("prodImage") MultipartFile prodImage) {
        try {
            String status = productService.addProduct(
                    prodName, prodType, prodInfo, prodPrice, prodQuantity, prodImage.getInputStream());
            return ResponseEntity.ok(status);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Error adding product: " + e.getMessage());
        }
    }

    /**
     * Get details of all products.
     */
    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    /**
     * Get details of a specific product by ID.
     */
    @GetMapping("/{prodId}")
    public Product getProductDetails(@PathVariable String prodId) {
        return productService.getProductDetails(prodId);
    }

    /**
     * Remove a product by ID.
     */
    @DeleteMapping("/remove/{prodId}")
    public String removeProduct(@PathVariable String prodId) {
        return productService.removeProduct(prodId);
    }

    /**
     * Update a product without an image.
     */
    @PutMapping("/update")
    public String updateProductWithoutImage(
            @RequestParam String prodId,
            @RequestBody Product updatedProduct) {
        return productService.updateProductWithoutImage(prodId, updatedProduct);
    }

    /**
     * Get a product's image as bytes.
     */
    @GetMapping("/{prodId}/image")
    public ResponseEntity<byte[]> getProductImage(@PathVariable String prodId) {
        byte[] image = productService.getImage(prodId);
        if (image != null) {
            return ResponseEntity.ok(image);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Search products by a keyword.
     */
    @GetMapping("/search")
    public List<Product> searchProducts(@RequestParam String keyword) {
        return productService.searchAllProducts(keyword);
    }

    /**
     * Get all products by type.
     */
    @GetMapping("/type/{type}")
    public List<Product> getProductsByType(@PathVariable String type) {
        return productService.getAllProductsByType(type);
    }
}
