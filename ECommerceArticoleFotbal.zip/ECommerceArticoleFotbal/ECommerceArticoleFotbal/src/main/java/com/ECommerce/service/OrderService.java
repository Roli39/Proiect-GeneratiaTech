package com.ECommerce.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ECommerce.Order;
import com.ECommerce.OrderDetails;
import com.ECommerce.Payment;

@Service
public interface OrderService {

	public String paymentSuccess(String userName, double paidAmount);

	public boolean addOrder(Order order);

	public boolean addTransaction(Payment transaction);

	public int countSoldItem(String prodId);

	public List<Order> getAllOrders();

	public List<Order> getOrdersByUserId(String emailId);

	public List<OrderDetails> getAllOrderDetails(String userEmailId);

	public String shipNow(String orderId, String prodId);
}
