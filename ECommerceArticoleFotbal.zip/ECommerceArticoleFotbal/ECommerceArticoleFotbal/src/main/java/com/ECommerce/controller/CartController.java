package com.ECommerce.controller;

import com.ECommerce.Cart;
import com.ECommerce.service.CartService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public String addProductToCart(@RequestParam String userId, @RequestParam String prodId, @RequestParam int prodQty) {
    	return cartService.addProductToCart(userId, prodId, prodQty);
    }

    @GetMapping("/{userId}/items")
    public List<Cart> getAllCartItems(@PathVariable String userId) {
        return cartService.getAllCartItems(userId);
    }

    @GetMapping("/{userId}/count")
    public int getCartCount(@PathVariable String userId) {
        return cartService.getCartCount(userId);
    }

    @DeleteMapping("/remove")
    public String removeProductFromCart(@RequestParam String userId, @RequestParam String prodId) {
        return cartService.removeProductFromCart(userId, prodId);
    }
}
