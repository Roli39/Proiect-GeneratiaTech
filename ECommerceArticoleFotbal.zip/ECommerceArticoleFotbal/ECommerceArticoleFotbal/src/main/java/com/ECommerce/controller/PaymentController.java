package com.ECommerce.controller;

import com.ECommerce.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    /**
     * Endpoint to get the user ID associated with a transaction ID.
     * 
     * @param transId Transaction ID
     * @return The user ID
     */
    @GetMapping("/user/{transId}")
    public String getUserIdByTransactionId(@PathVariable String transId) {
        return paymentService.getUserId(transId);
    }
}
