package com.ECommerce.service;

import org.springframework.stereotype.Service;

@Service
public interface PaymentService {

	public String getUserId(String transId);
}
